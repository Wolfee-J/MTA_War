--
-- c_vehicle.lua
-- 

local myShader, myTexture, myObject
addEventHandler( "onClientResourceStart", resourceRoot, function()
	
	local myTexture = dxCreateTexture("battle_rifle_bump.png", "dxt5")
	local myShader = dxCreateShader("normalmap.fx", 0, 25, false, "all")
	if not myShader and not myTexture then return end
	
	engineImportTXD ( engineLoadTXD ( "BR.txd" ), 4729 )
	engineReplaceModel ( engineLoadDFF ( "BR.dff" ), 4729 )
	
	-- Create object with model 4729 (billboard)
	local x,y,z = getElementPosition( localPlayer )
	myObject = createObject ( 4729, x, y, z, 0, 0, 0, true)
	setElementDoubleSided ( myObject, true )
	
	dxSetShaderValue(myShader, "gTextureNormal", myTexture)
	engineApplyShaderToWorldTexture ( myShader, "battle_rifle", myObject )
	
end)

local myRot, localFPS = 0, 0
addEventHandler( "onClientPreRender", root, function()
	if not myObject then return end
	myRot = myRot + 0.4 * ( 25 / localFPS )
	if myRot > 360 then myRot = 0 end	
	setElementRotation ( myObject, myRot, myRot, myRot )
end)

local function updateFPS(msSinceLastFrame)
    localFPS = (1 / msSinceLastFrame) * 1000
end
addEventHandler("onClientPreRender", root, updateFPS)